# -*- coding: utf-8 -*-
H='\u09cd'; ZW=('\u200c','\u200d')
BASE={'ক':'K','খ':'L','গ':'M','ঘ':'N','ঙ':'O','চ':'P','ছ':'Q','জ':'R','ঝ':'S','ঞ':'T','ট':'U','ঠ':'V','ড':'W','ঢ':'X','ণ':'Y','ত':'Z','থ':'_','দ':'`','ধ':'a','ন':'b','প':'c','ফ':'d','ব':'e','ভ':'f','ম':'g','য':'h','র':'i','ল':'j','শ':'k','ষ':'l','স':'m','হ':'n','\u09dc':'o','\u09dd':'p','\u09df':'q'}
OTHER={'ৎ':'r','ং':'s','ঃ':'t','ঁ':'u','অ':'A','আ':'Av','ই':'B','ঈ':'C','উ':'D','ঊ':'E','ঋ':'F','এ':'G','ঐ':'H','ও':'I','ঔ':'J',
 '০':'0','১':'1','২':'2','৩':'3','৪':'4','৫':'5','৬':'6','৭':'7','৮':'8','৯':'9','।':'|','ঽ':'ঽ'}
KAR_POST={'া':'v','ী':'x','ু':'y','ূ':'~','ৃ':'\u201e'}
KAR_PRE={'ি':'w','ে':'\u2021','ৈ':'\u02dc'}
LIG={'ক্ষ':'\u00b6','ক্ত':'\u00b3','ক্র':'\u00b5','ত্র':'\u00ce','ত্ত':'\u00cb','ন্ত':'\u0161\u00cd','ন্দ':'\u203a`','ম্প':'\u00a4\u00fa','ম্ম':'\u00a4\u00a7','ম্ব':'\u00a4^','স্ব':'\u00af^','স্ক':'\u00af\u2039','স্থ':'\u00af\u2019','স্ত':'\u00afZ','চ্চ':'\u201dP','চ্ছ':'\u201dQ','জ্জ':'\u00be','জ্ঞ':'\u00c1','ঙ্গ':'\u00bd','ঙ্ক':'\u00bc','গ্ন':'M\u0153','ষ্ট':'\u00f3','ষ্ঠ':'\u00f4','প্ত':'\u00df','দ্ধ':'\u00d7','দ্ব':'`\u00a6'}
RAPHALA={'প':'\u00d6','গ':'\u00d6','শ':'\u00d6','ব':'\u00aa','ভ':'\u00aa','ড':'\u00aa','ট':'\u00aa','দ':'\u00aa','স':'\u00aa'}
NEUTRAL_BN={'\u2018':'\u00d4','\u2019':'\u00d5','\u201c':'\u00d2','\u201d':'\u00d3'}
def iscons(c): return c in BASE
def norm(s):
    for a,b in (('ড\u09bc','\u09dc'),('ঢ\u09bc','\u09dd'),('য\u09bc','\u09df'),('\u09c7\u09be','ো'),('\u09c7\u09d7','ৌ')): s=s.replace(a,b)
    return s
def cluster_glyphs(cons):
    res='';i=0;n=len(cons)
    while i<n:
        m=False
        for L in range(min(4,n-i),1,-1):
            k=H.join(cons[i:i+L])
            if k in LIG: res+=LIG[k]; i+=L; m=True; break
        if m: continue
        c=cons[i]
        if i==0: res+=BASE[c]
        elif c=='য': res+='\u00a8'
        elif c=='র': res+=RAPHALA.get(cons[i-1],'&i')
        else: res+='&'+BASE[c]
        i+=1
    return res
def convert(u):
    s=norm(u); out=[]; i=0; n=len(s)
    while i<n:
        c=s[i]
        if iscons(c) or c in KAR_PRE or c in KAR_POST or c in 'োৌ':
            ref=False; body=''
            if iscons(c):
                if c=='র' and i+2<n and s[i+1]==H and iscons(s[i+2]): ref=True; i+=2
                cons=[s[i]]; i+=1
                while True:
                    j=i
                    while j<n and s[j] in ZW: j+=1
                    if j+1<n and s[j]==H and iscons(s[j+1]): cons.append(s[j+1]); i=j+2
                    else: break
                body=cluster_glyphs(cons)
                if i<n and s[i]==H:
                    body+='&'; i+=1
                    while i<n and s[i] in ZW: i+=1
            pre='';post=''
            while i<n and (s[i] in KAR_PRE or s[i] in KAR_POST or s[i] in 'োৌ'):
                k=s[i]
                if k in KAR_PRE: pre+=KAR_PRE[k]
                elif k=='ো': pre+='\u2021'; post+='v'
                elif k=='ৌ': pre+='\u2021'; post+='\u0160'
                else: post+=KAR_POST[k]
                i+=1
            out.append(pre+body+('\u00a9' if ref else '')+post)
        elif c in OTHER: out.append(OTHER[c]); i+=1
        elif c in ZW: i+=1
        else: out.append(c); i+=1
    return ''.join(out)
if __name__=='__main__':
    T={'বাংলা':'evsjv','আমি':'Avwg','শিক্ষা':'wk\u00b6v','সুন্দর':'my\u203a`i','ধর্ম':'ag\u00a9','প্রথম':'c\u00d6_g','উত্তর':'D\u00cbi','শান্তি':'kvw\u0161\u00cd','বিজ্ঞান':'we\u00c1vb','সম্পর্ক':'m\u00a4\u00faK\u00a9','ব্যবহার':'e\u00a8envi','কোথায়':'\u2021Kv_vq','দৈনিক':'\u02dc`wbK','ইচ্ছা':'B\u201dQv','যুক্ত':'hy\u00b3','সৃষ্টি':'m\u201ewh'.replace('h','\u00f3') ,'১২৩।':'123|','সূর্য':'m~h\u00a9','বাংলাদেশ':'evsjv\u2021`k','কর্মী':'Kg\u00a9x','র‍্যাব':'i\u00a8vev'.replace('i\u00a8vev','i\u00a8ve'),}
    # fix: র‍্যাব = ra+ya-phala, aa, ba -> i¨ve? (v then e)
    T['র‍্যাব']='i\u00a8ve'.replace('ve','v')+'e' if False else 'i\u00a8ve'
    bad=0
    for k,v in T.items():
        r=convert(k)
        ok = r==v
        if not ok: bad+=1
        print('OK ' if ok else 'BAD',k,repr(r),repr(v))
    print('bad',bad)
