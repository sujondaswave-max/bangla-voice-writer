# -*- coding: utf-8 -*-
H='\u09cd'
CONS={'kkh':'ক'+H+'ষ','chh':'ছ','ch':'চ','kh':'খ','gh':'ঘ','Ng':'ঙ','jh':'ঝ','NG':'ঞ','Th':'ঠ','Dh':'ঢ','th':'থ','dh':'ধ','ph':'ফ','bh':'ভ','sh':'শ','Sh':'ষ','Rh':'\u09dd','GG':'জ'+H+'ঞ',
 'k':'ক','g':'গ','c':'চ','j':'জ','T':'ট','D':'ড','N':'ণ','t':'ত','d':'দ','n':'ন','p':'প','f':'ফ','b':'ব','v':'ভ','m':'ম','z':'য','r':'র','l':'ল','S':'শ','s':'স','h':'হ','R':'\u09dc','y':'\u09df','Y':'\u09df','q':'ক','x':'ক'+H+'স'}
SPECIAL={'ng':'ং',',,':H,'t``':'ৎ','^':'ঁ',':':'ঃ','.':'।','$':'৳'}
VOW={'rri':('ঋ','ৃ'),'oi':('ঐ','ৈ'),'ou':('ঔ','ৌ'),'oU':('ঔ','ৌ'),'ii':('ঈ','ী'),'uu':('ঊ','ূ'),'a':('আ','া'),'i':('ই','ি'),'I':('ঈ','ী'),'u':('উ','ু'),'U':('ঊ','ূ'),'e':('এ','ে'),'O':('ও','ো'),'o':('অ','')}
DIG=dict(zip('0123456789','০১২৩৪৫৬৭৮৯'))
def tr(t):
    out=[];i=0;n=len(t);state='start'   # start|vowel|cons|mark
    while i<n:
        ch=t[i]
        if ch=='`': state='closed' if state=='cons' else state; i+=1; continue
        if ch in DIG: out.append(DIG[ch]); state='start'; i+=1; continue
        m=None
        for L in (3,2):
            k=t[i:i+L]
            if len(k)==L and k in SPECIAL and k not in ('ng',) : m=('s',k,L);break
        if not m:
            for L in (3,2,1):
                k=t[i:i+L]
                if len(k)<L: continue
                if k in VOW and L>1: m=('v',k,L);break
                if k in SPECIAL and (L>1 or k in '^:.$'): m=('s',k,L);break
                if k in CONS: m=('c',k,L);break
                if k in VOW: m=('v',k,L);break
        if not m: out.append(ch); state='start'; i+=1; continue
        typ,k,L=m; i+=L
        if typ=='s':
            if k==',,': out.append(H); state='cons'
            else: out.append(SPECIAL[k]); state='mark' if k in('ng','^',':','t``') else 'start'
        elif typ=='v':
            ind,kar=VOW[k]
            if state=='cons': out.append(kar)
            else: out.append(ind)
            state='vowel'
        else:
            g=CONS[k]
            if state=='cons':
                if k=='y': out.append(H+'য')
                else: out.append(H+g)
            else: out.append(g)
            state='cons'
    return ''.join(out)
if __name__=='__main__':
    T={'ami':'আমি','amar':'আমার','bangla':'বাংলা','bangladesh':'বাংলাদেশ','tumi':'তুমি','shikkha':'শিক্ষা','prothom':'প্রথম','dhormo':'ধর্ম','sundor':'সুন্দর','kothay':'কথায়','Dhaka':'ঢাকা','ki khobor':'কি খবর','amra':'আমরা','biggan':'বিগ্গান','kyampas':'ক্যামপাস','tk 12.':'তক ১২।','bhalo':'ভাল','kOn':'কোন','hoi':'হই','rrishi':'ঋষি'.replace('ঋষি','ঋষি')}
    bad=0
    for k,v in T.items():
        r=tr(k); ok=r==v; bad+=not ok
        print('OK ' if ok else 'BAD',k,r,v)
    print('bad',bad)
