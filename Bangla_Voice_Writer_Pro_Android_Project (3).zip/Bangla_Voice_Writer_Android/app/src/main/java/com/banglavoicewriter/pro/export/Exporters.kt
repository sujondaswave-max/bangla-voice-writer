package com.banglavoicewriter.pro.export

import com.banglavoicewriter.pro.convert.BijoyConverter

object Exporters {
    private val UTF8_BOM = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())

    /**
     * Unicode  -> UTF-8 with BOM (so Windows Notepad / Word detect it).
     * SutonnyMJ -> Bijoy ANSI text stored as Windows-1252 bytes, which is what
     * legacy Bijoy software expects for plain-text files.
     */
    fun txtBytes(text: String, sutonny: Boolean): ByteArray =
        if (sutonny) {
            BijoyConverter.toBijoy(text).toByteArray(charset("windows-1252"))
        } else {
            UTF8_BOM + text.toByteArray(Charsets.UTF_8)
        }
}
