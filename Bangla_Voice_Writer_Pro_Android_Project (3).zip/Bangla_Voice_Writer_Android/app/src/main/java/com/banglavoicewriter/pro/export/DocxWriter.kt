package com.banglavoicewriter.pro.export

import com.banglavoicewriter.pro.convert.BijoyConverter
import com.banglavoicewriter.pro.convert.Script
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Minimal, dependency-free .docx writer (WordprocessingML in a ZIP).
 *
 * Unicode mode : text kept as Unicode, Bangla runs use the complex-script font "Nirmala UI".
 * SutonnyMJ mode: text is converted to Bijoy ANSI; Bangla runs are tagged with font
 *   "SutonnyMJ" (NOT embedded: the document shows correctly on computers that have
 *   SutonnyMJ installed). English runs stay in a normal Latin font so they do not turn
 *   into Bangla glyphs.
 */
object DocxWriter {
    const val SUTONNY_FONT = "SutonnyMJ"
    private const val LATIN_FONT = "Calibri"
    private const val UNICODE_BANGLA_FONT = "Nirmala UI"
    private const val SIZE_HALF_POINTS = 28 // 14 pt

    private const val CONTENT_TYPES =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"

    private const val ROOT_RELS =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"

    fun build(text: String, sutonny: Boolean): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { zip ->
            fun entry(name: String, content: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            entry("[Content_Types].xml", CONTENT_TYPES)
            entry("_rels/.rels", ROOT_RELS)
            entry("word/document.xml", documentXml(text, sutonny))
        }
        return bos.toByteArray()
    }

    internal fun documentXml(text: String, sutonny: Boolean): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        sb.append("<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>")
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split("\n")
        for (line in lines) {
            if (line.isEmpty()) {
                sb.append("<w:p/>")
                continue
            }
            sb.append("<w:p>")
            if (sutonny) {
                for (seg in BijoyConverter.convertSegments(line)) {
                    val font = if (seg.script == Script.BANGLA) SUTONNY_FONT else LATIN_FONT
                    sb.append(run(seg.text, rFonts(font, font, font, font), null))
                }
            } else {
                sb.append(run(line, rFonts(LATIN_FONT, LATIN_FONT, UNICODE_BANGLA_FONT, UNICODE_BANGLA_FONT), "bn-BD"))
            }
            sb.append("</w:p>")
        }
        sb.append(
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
                "<w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" " +
                "w:header=\"720\" w:footer=\"720\" w:gutter=\"0\"/></w:sectPr>"
        )
        sb.append("</w:body></w:document>")
        return sb.toString()
    }

    private fun rFonts(ascii: String, hAnsi: String, cs: String, eastAsia: String) =
        "<w:rFonts w:ascii=\"$ascii\" w:hAnsi=\"$hAnsi\" w:cs=\"$cs\" w:eastAsia=\"$eastAsia\"/>"

    private fun run(text: String, fonts: String, bidiLang: String?): String {
        val lang = if (bidiLang != null) "<w:lang w:bidi=\"$bidiLang\"/>" else ""
        return "<w:r><w:rPr>$fonts<w:sz w:val=\"$SIZE_HALF_POINTS\"/>" +
            "<w:szCs w:val=\"$SIZE_HALF_POINTS\"/>$lang</w:rPr>" +
            "<w:t xml:space=\"preserve\">${escape(text)}</w:t></w:r>"
    }

    internal fun escape(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (c in s) {
            when {
                c == '&' -> sb.append("&amp;")
                c == '<' -> sb.append("&lt;")
                c == '>' -> sb.append("&gt;")
                c == '"' -> sb.append("&quot;")
                c == '\t' -> sb.append("    ")
                c.code < 0x20 -> {} // illegal in XML 1.0: drop
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }
}
