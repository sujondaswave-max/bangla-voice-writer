package com.banglavoicewriter.pro.speech

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognitionSupport
import android.speech.RecognitionSupportCallback
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.annotation.RequiresApi

/** State of the on-device (offline) language pack for the selected language. */
enum class OfflineStatus { UNKNOWN, CHECKING, AVAILABLE, DOWNLOAD_NEEDED, NOT_SUPPORTED }

interface SpeechCallbacks {
    fun onListening(active: Boolean)
    fun onPartial(text: String)
    fun onFinal(text: String)
    fun onMessage(message: String)
}

/**
 * Wraps Android's SpeechRecognizer (the phone's own speech service, normally
 * Google). It provides live partial results, continuous dictation (automatic
 * restart after each phrase), and online / on-device selection.
 *
 * There is NO bundled recognition model: accuracy and offline availability are
 * decided by the phone's speech service and its downloaded language packs.
 */
class SpeechController(
    private val context: Context,
    private val callbacks: SpeechCallbacks
) {
    var languageTag: String = "bn-BD"
    var offline: Boolean = false
    var continuous: Boolean = true

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var checker: SpeechRecognizer? = null
    private var active = false
    private var errorStreak = 0

    val isActive: Boolean get() = active

    fun start() {
        if (active) return
        if (!createRecognizer()) return
        active = true
        errorStreak = 0
        callbacks.onListening(true)
        listen()
    }

    /** Ends dictation; a last pending phrase is still delivered. */
    fun stop() {
        if (!active) return
        active = false
        callbacks.onListening(false)
        try {
            recognizer?.stopListening()
        } catch (_: Exception) {
        }
        // Safety net: free the recognizer even if no final callback arrives.
        main.postDelayed({ if (!active) destroyRecognizer() }, 2500)
    }

    fun destroy() {
        active = false
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
        try {
            checker?.destroy()
        } catch (_: Exception) {
        }
        checker = null
    }

    private fun createRecognizer(): Boolean {
        destroyRecognizer()
        val rec: SpeechRecognizer? = try {
            if (offline && Build.VERSION.SDK_INT >= 33 &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
            ) {
                createOnDevice()
            } else if (SpeechRecognizer.isRecognitionAvailable(context)) {
                SpeechRecognizer.createSpeechRecognizer(context)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
        if (rec == null) {
            callbacks.onMessage(
                "No speech recognition service found on this phone. " +
                    "Install or enable the Google app / Speech Services."
            )
            return false
        }
        rec.setRecognitionListener(listener)
        recognizer = rec
        return true
    }

    @RequiresApi(31)
    private fun createOnDevice(): SpeechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)

    private fun destroyRecognizer() {
        try {
            recognizer?.destroy()
        } catch (_: Exception) {
        }
        recognizer = null
    }

    private fun buildIntent(tag: String, preferOffline: Boolean): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }

    private fun listen() {
        try {
            recognizer?.startListening(buildIntent(languageTag, offline))
        } catch (e: Exception) {
            failAndStop("Could not start listening: ${e.message}")
        }
    }

    private fun restartSoon(delayMs: Long = 150) {
        main.postDelayed({ if (active) listen() }, delayMs)
    }

    private fun failAndStop(message: String) {
        active = false
        callbacks.onPartial("")
        callbacks.onListening(false)
        callbacks.onMessage(message)
        destroyRecognizer()
    }

    private fun finishQuietly() {
        callbacks.onPartial("")
        destroyRecognizer()
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {
            errorStreak = 0
        }

        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!t.isNullOrBlank()) callbacks.onPartial(t)
        }

        override fun onResults(results: Bundle?) {
            errorStreak = 0
            callbacks.onPartial("")
            val t = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!t.isNullOrBlank()) callbacks.onFinal(t)
            if (active && continuous) {
                restartSoon()
            } else {
                if (active) {
                    active = false
                    callbacks.onListening(false)
                }
                finishQuietly()
            }
        }

        override fun onError(error: Int) {
            callbacks.onPartial("")
            if (!active) {
                finishQuietly()
                return
            }
            when (error) {
                // 7 = ERROR_NO_MATCH, 6 = ERROR_SPEECH_TIMEOUT: just silence.
                7, 6 -> {
                    if (continuous) {
                        restartSoon(250)
                    } else {
                        active = false
                        callbacks.onListening(false)
                        callbacks.onMessage("Nothing was heard. Tap the microphone and try again.")
                        finishQuietly()
                    }
                }
                // 8 = ERROR_RECOGNIZER_BUSY, 5 = ERROR_CLIENT
                8, 5 -> {
                    errorStreak++
                    if (errorStreak > 4) {
                        failAndStop("Speech service is busy. Please try again in a moment.")
                    } else {
                        try {
                            recognizer?.cancel()
                        } catch (_: Exception) {
                        }
                        restartSoon(600)
                    }
                }
                9 -> failAndStop("Microphone permission is missing.")
                3 -> failAndStop("Audio recording error. Check that no other app is using the microphone.")
                1, 2 -> failAndStop(
                    if (offline) "Offline recognition failed. Download the offline language pack or switch to Online."
                    else "Network error. Check your internet connection or switch to Offline."
                )
                4 -> failAndStop("Speech server error. Try again later.")
                // 12 = ERROR_LANGUAGE_NOT_SUPPORTED, 13 = ERROR_LANGUAGE_UNAVAILABLE
                12, 13 -> failAndStop(
                    "This language is not available " + (if (offline) "offline on this phone. Download the offline pack, or use Online mode." else "on this phone's speech service.")
                )
                else -> failAndStop("Speech recognition error (code $error).")
            }
        }
    }

    // ---------------------------------------------------------------- offline pack

    /** Asks the phone whether the offline language pack for [tag] is installed (Android 13+). */
    fun checkOfflineSupport(tag: String, onResult: (OfflineStatus) -> Unit) {
        if (Build.VERSION.SDK_INT < 33) {
            onResult(OfflineStatus.UNKNOWN)
            return
        }
        try {
            if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
                onResult(OfflineStatus.NOT_SUPPORTED)
                return
            }
            checkApi33(tag, onResult)
        } catch (e: Exception) {
            onResult(OfflineStatus.UNKNOWN)
        }
    }

    @RequiresApi(33)
    private fun checkApi33(tag: String, onResult: (OfflineStatus) -> Unit) {
        try {
            checker?.destroy()
        } catch (_: Exception) {
        }
        val rec = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        checker = rec
        val lang = tag.substringBefore('-').lowercase()
        fun matches(list: List<String>) = list.any { it.substringBefore('-').lowercase() == lang }
        rec.checkRecognitionSupport(
            buildIntent(tag, true),
            context.mainExecutor,
            object : RecognitionSupportCallback {
                override fun onSupportResult(recognitionSupport: RecognitionSupport) {
                    val status = when {
                        matches(recognitionSupport.installedOnDeviceLanguages) -> OfflineStatus.AVAILABLE
                        matches(recognitionSupport.pendingOnDeviceLanguages) ||
                            matches(recognitionSupport.supportedOnDeviceLanguages) -> OfflineStatus.DOWNLOAD_NEEDED
                        else -> OfflineStatus.NOT_SUPPORTED
                    }
                    onResult(status)
                }

                override fun onError(error: Int) {
                    onResult(OfflineStatus.UNKNOWN)
                }
            }
        )
    }

    /** Requests download of the offline pack (Android 13+). Returns false if unsupported. */
    fun requestOfflineDownload(tag: String): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        return try {
            triggerApi33(tag)
            true
        } catch (e: Exception) {
            false
        }
    }

    @RequiresApi(33)
    private fun triggerApi33(tag: String) {
        val rec = checker ?: SpeechRecognizer.createOnDeviceSpeechRecognizer(context).also { checker = it }
        rec.triggerModelDownload(buildIntent(tag, true))
    }
}
