package com.banglavoicewriter.pro.export

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.MetricAffectingSpan
import com.banglavoicewriter.pro.convert.BijoyConverter
import com.banglavoicewriter.pro.convert.Script
import java.io.OutputStream

/** Thrown when SutonnyMJ PDF export is requested but no font file has been imported. */
class FontMissingException : Exception("SutonnyMJ font file has not been imported.")

/**
 * A4 PDF export using Android's built-in PdfDocument (fonts are embedded by the platform).
 * Unicode mode relies on the phone's own Bangla system font and text shaping.
 * SutonnyMJ mode requires the user's imported font file; without it we refuse
 * rather than produce a PDF that looks wrong.
 */
object PdfWriter {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 50
    private const val TEXT_SIZE = 14f

    private class FaceSpan(private val face: Typeface) : MetricAffectingSpan() {
        override fun updateDrawState(tp: TextPaint) {
            tp.typeface = face
        }

        override fun updateMeasureState(tp: TextPaint) {
            tp.typeface = face
        }
    }

    fun write(text: String, sutonny: Boolean, sutonnyFace: Typeface?, out: OutputStream) {
        val content: CharSequence
        if (sutonny) {
            val face = sutonnyFace ?: throw FontMissingException()
            val sb = SpannableStringBuilder()
            for (seg in BijoyConverter.convertSegments(text.replace("\r\n", "\n"))) {
                val start = sb.length
                sb.append(seg.text)
                if (seg.script == Script.BANGLA && seg.text.isNotEmpty()) {
                    sb.setSpan(FaceSpan(face), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            content = sb
        } else {
            content = text.replace("\r\n", "\n")
        }

        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = TEXT_SIZE
            typeface = Typeface.DEFAULT
        }
        val contentW = PAGE_W - 2 * MARGIN
        val layout = StaticLayout.Builder
            .obtain(content, 0, content.length, paint, contentW)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.3f)
            .setIncludePad(false)
            .build()

        val pageH = PAGE_H - 2 * MARGIN
        val doc = PdfDocument()
        try {
            var line = 0
            var pageNo = 1
            do {
                val top = layout.getLineTop(line)
                var end = line
                while (end < layout.lineCount && layout.getLineBottom(end) - top <= pageH) end++
                if (end == line) end = line + 1
                val bottom = layout.getLineBottom(end - 1)

                val page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
                val canvas = page.canvas
                canvas.save()
                canvas.translate(MARGIN.toFloat(), (MARGIN - top).toFloat())
                canvas.clipRect(0f, top.toFloat(), contentW.toFloat(), bottom.toFloat())
                layout.draw(canvas)
                canvas.restore()
                doc.finishPage(page)

                line = end
                pageNo++
            } while (line < layout.lineCount)
            doc.writeTo(out)
        } finally {
            doc.close()
        }
    }
}
