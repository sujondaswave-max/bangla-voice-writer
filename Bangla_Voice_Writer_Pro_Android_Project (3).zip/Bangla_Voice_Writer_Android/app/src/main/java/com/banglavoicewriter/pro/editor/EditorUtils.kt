package com.banglavoicewriter.pro.editor

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Undo / redo history over whole-text snapshots. Fast typing is coalesced. */
class UndoManager(private val limit: Int = 200) {
    private val undoStack = ArrayList<String>()
    private val redoStack = ArrayList<String>()
    private var lastEdit = 0L

    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    /** Call for every change. [force] = a discrete action (voice insert, paste, clear...). */
    fun record(before: String, after: String, force: Boolean) {
        if (before == after) return
        val now = SystemClock.uptimeMillis()
        val bigChange = kotlin.math.abs(after.length - before.length) > 1
        if (force || bigChange || now - lastEdit > 800 || undoStack.isEmpty()) {
            undoStack.add(before)
            if (undoStack.size > limit) undoStack.removeAt(0)
        }
        lastEdit = now
        redoStack.clear()
        refresh()
    }

    fun undo(current: String): String? {
        if (undoStack.isEmpty()) return null
        redoStack.add(current)
        val previous = undoStack.removeAt(undoStack.lastIndex)
        lastEdit = 0L
        refresh()
        return previous
    }

    fun redo(current: String): String? {
        if (redoStack.isEmpty()) return null
        undoStack.add(current)
        val next = redoStack.removeAt(redoStack.lastIndex)
        lastEdit = 0L
        refresh()
        return next
    }

    private fun refresh() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }
}

/** Result of inserting text: the new full text and the new cursor position. */
data class InsertResult(val text: String, val cursor: Int)

object TextInsert {
    private const val NO_SPACE_BEFORE = ".,;:!?\u0964)]}\u201D'\""

    /** Inserts exactly [s] at the selection (replacing it). */
    fun exact(text: String, selStart: Int, selEnd: Int, s: String): InsertResult {
        val a = minOf(selStart, selEnd).coerceIn(0, text.length)
        val b = maxOf(selStart, selEnd).coerceIn(0, text.length)
        return InsertResult(text.substring(0, a) + s + text.substring(b), a + s.length)
    }

    /** Inserts recognised speech, adding a separating space where sensible. */
    fun spoken(text: String, selStart: Int, selEnd: Int, spoken: String): InsertResult {
        val a = minOf(selStart, selEnd).coerceIn(0, text.length)
        val b = maxOf(selStart, selEnd).coerceIn(0, text.length)
        val ins = spoken.trim()
        if (ins.isEmpty()) return InsertResult(text, a)
        val before = text.substring(0, a)
        val after = text.substring(b)
        val prefix = if (before.isNotEmpty() && !before.last().isWhitespace() && ins[0] !in NO_SPACE_BEFORE) " " else ""
        val suffix = if (after.isNotEmpty() && !after[0].isWhitespace() && after[0] !in NO_SPACE_BEFORE) " " else ""
        val inserted = prefix + ins + suffix
        return InsertResult(before + inserted + after, a + prefix.length + ins.length)
    }
}
