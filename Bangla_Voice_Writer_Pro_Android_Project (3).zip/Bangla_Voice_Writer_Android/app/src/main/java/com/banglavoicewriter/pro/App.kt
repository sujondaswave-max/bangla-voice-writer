package com.banglavoicewriter.pro

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.banglavoicewriter.pro.convert.AvroPhonetic
import com.banglavoicewriter.pro.convert.BijoyConverter
import com.banglavoicewriter.pro.convert.BijoyToUnicode
import com.banglavoicewriter.pro.convert.Script
import com.banglavoicewriter.pro.editor.TextInsert
import com.banglavoicewriter.pro.editor.UndoManager
import com.banglavoicewriter.pro.export.DocxWriter
import com.banglavoicewriter.pro.export.Exporters
import com.banglavoicewriter.pro.export.FontStore
import com.banglavoicewriter.pro.export.PdfWriter
import com.banglavoicewriter.pro.speech.OfflineStatus
import com.banglavoicewriter.pro.speech.SpeechCallbacks
import com.banglavoicewriter.pro.speech.SpeechController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

/** Words that exercise kar, reph, ya/ra-phala and conjuncts. Convert, export to DOCX and check in Word. */
private val BIJOY_TEST_WORDS = listOf(
    "বাংলা", "আমি", "শিক্ষা", "সুন্দর", "ধর্ম", "প্রথম", "উত্তর", "শান্তি", "বিজ্ঞান",
    "সম্পর্ক", "ব্যবহার", "কোথায়", "দৈনিক", "ইচ্ছা", "যুক্ত", "সৃষ্টি", "সূর্য", "কর্মী",
    "কৌশল", "স্বাধীন", "সম্মান", "বুদ্ধি", "অঙ্গ", "সপ্তাহ", "ক্ষমতা", "রাষ্ট্র", "ট্রেন", "ভদ্র",
    "র‍্যাব", "চাঁদ", "সংখ্যা ১২৩৪৫৬৭৮৯০", "আমার সোনার বাংলা, আমি তোমায় ভালবাসি।",
    "Mixed English text 2026 is kept in a Latin font."
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BanglaVoiceWriterApp(activity: ComponentActivity) {
    val context: Context = activity
    val prefs = remember { context.getSharedPreferences("bvw_prefs", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val fontStore = remember { FontStore(context) }
    val undo = remember { UndoManager() }
    val focus = remember { FocusRequester() }

    val draft = remember { prefs.getString("draft", "") ?: "" }
    var tfv by remember { mutableStateOf(TextFieldValue(draft, TextRange(draft.length))) }
    var langBangla by remember { mutableStateOf(prefs.getBoolean("lang_bn", true)) }
    var offline by remember { mutableStateOf(prefs.getBoolean("offline", false)) }
    var sutonny by remember { mutableStateOf(prefs.getBoolean("sutonny", false)) }
    var avroMode by remember { mutableStateOf(prefs.getBoolean("avro", false)) }
    var showSettings by remember { mutableStateOf(true) }
    var listening by remember { mutableStateOf(false) }
    var partial by remember { mutableStateOf("") }
    var offlineStatus by remember { mutableStateOf(OfflineStatus.UNKNOWN) }
    var phonetic by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showFontDialog by remember { mutableStateOf(false) }
    var font by remember { mutableStateOf(fontStore.load()) }

    fun say(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    fun setText(new: TextFieldValue, force: Boolean) {
        undo.record(tfv.text, new.text, force)
        tfv = new
    }

    fun insertSpoken(s: String) {
        val r = TextInsert.spoken(tfv.text, tfv.selection.start, tfv.selection.end, s)
        setText(TextFieldValue(r.text, TextRange(r.cursor)), true)
    }

    fun insertExact(s: String) {
        val r = TextInsert.exact(tfv.text, tfv.selection.start, tfv.selection.end, s)
        setText(TextFieldValue(r.text, TextRange(r.cursor)), true)
    }

    fun savePrefs() {
        prefs.edit()
            .putString("draft", tfv.text)
            .putBoolean("lang_bn", langBangla)
            .putBoolean("offline", offline)
            .putBoolean("sutonny", sutonny)
            .putBoolean("avro", avroMode)
            .apply()
    }

    val controller = remember {
        SpeechController(context, object : SpeechCallbacks {
            override fun onListening(active: Boolean) {
                listening = active
            }

            override fun onPartial(text: String) {
                partial = text
            }

            override fun onFinal(text: String) {
                insertSpoken(text)
            }

            override fun onMessage(message: String) {
                say(message)
            }
        })
    }

    fun langTag() = if (langBangla) "bn-BD" else "en-US"

    fun startListening() {
        controller.languageTag = langTag()
        controller.offline = offline
        controller.continuous = true
        if (offline && (offlineStatus == OfflineStatus.DOWNLOAD_NEEDED || offlineStatus == OfflineStatus.NOT_SUPPORTED)) {
            say("Offline language model is not available. Download it or switch to Online.")
        }
        controller.start()
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else say("Microphone permission is required for voice typing.")
    }

    fun toggleMic() {
        if (listening) {
            controller.stop()
            return
        }
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(offline, langBangla) {
        if (offline) {
            offlineStatus = OfflineStatus.CHECKING
            controller.checkOfflineSupport(langTag()) { offlineStatus = it }
        } else {
            offlineStatus = OfflineStatus.UNKNOWN
        }
    }

    DisposableEffect(Unit) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                savePrefs()
                controller.stop()
            }
        }
        activity.lifecycle.addObserver(observer)
        onDispose {
            activity.lifecycle.removeObserver(observer)
            savePrefs()
            controller.destroy()
        }
    }

    // ------------------------------------------------------------------ export

    fun fileName(ext: String) = "bangla_note_" + (if (sutonny) "sutonnymj" else "unicode") + "." + ext

    fun exportTo(uri: Uri, kind: String) {
        val text = tfv.text
        val sut = sutonny
        val face = font
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val os = context.contentResolver.openOutputStream(uri) ?: error("Cannot open the destination file")
                    os.use {
                        when (kind) {
                            "txt" -> it.write(Exporters.txtBytes(text, sut))
                            "docx" -> it.write(DocxWriter.build(text, sut))
                            else -> PdfWriter.write(text, sut, face, it)
                        }
                    }
                }
            }
            result
                .onSuccess { say("Saved") }
                .onFailure { e -> say("Export failed: " + (e.message ?: e.javaClass.simpleName)) }
        }
    }

    val txtLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) exportTo(uri, "txt")
    }
    val docxLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(DOCX_MIME)) { uri ->
        if (uri != null) exportTo(uri, "docx")
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportTo(uri, "pdf")
    }
    val fontLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val err = withContext(Dispatchers.IO) { fontStore.importFrom(uri) }
                if (err == null) {
                    font = fontStore.load()
                    say("Font imported")
                } else {
                    say(err)
                }
            }
        }
    }

    // --------------------------------------------------------------- clipboard

    fun clipboard() = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    fun copyText() {
        val sel = tfv.selection
        val src = if (!sel.collapsed) tfv.text.substring(sel.min, sel.max) else tfv.text
        if (src.isEmpty()) {
            say("Nothing to copy")
            return
        }
        val out = if (sutonny) BijoyConverter.toBijoy(src) else src
        clipboard().setPrimaryClip(ClipData.newPlainText("Bangla text", out))
        say(if (sutonny) "Copied as SutonnyMJ (Bijoy ANSI)" else "Copied (Unicode)")
    }

    fun pasteText(fromBijoy: Boolean) {
        val clip = clipboard().primaryClip
        val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(context).toString() else ""
        if (t.isEmpty()) {
            say("Clipboard is empty")
            return
        }
        insertExact(if (fromBijoy) BijoyToUnicode.convert(t) else t)
    }

    fun selectAll() {
        try {
            focus.requestFocus()
        } catch (_: Exception) {
        }
        tfv = tfv.copy(selection = TextRange(0, tfv.text.length))
    }

    fun doUndo() {
        val p = undo.undo(tfv.text)
        if (p != null) tfv = TextFieldValue(p, TextRange(p.length))
    }

    fun doRedo() {
        val p = undo.redo(tfv.text)
        if (p != null) tfv = TextFieldValue(p, TextRange(p.length))
    }

    // ---------------------------------------------------------------------- UI

    val langName = if (langBangla) "বাংলা" else "English"
    val ansiPreview: AnnotatedString? = remember(tfv.text, font, sutonny) {
        if (!sutonny) {
            null
        } else {
            val f = font
            buildAnnotatedString {
                for (seg in BijoyConverter.convertSegments(tfv.text)) {
                    if (seg.script == Script.BANGLA && f != null) {
                        withStyle(SpanStyle(fontFamily = FontFamily(f))) { append(seg.text) }
                    } else {
                        append(seg.text)
                    }
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Bangla Voice Writer Pro", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                actions = {
                    IconButton(onClick = { showSettings = !showSettings }) {
                        Icon(Icons.Filled.Tune, contentDescription = "Show or hide settings")
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Paste Bijoy text as Unicode") }, onClick = {
                                menuOpen = false
                                pasteText(true)
                            })
                            DropdownMenuItem(text = { Text("Convert editor text: Bijoy to Unicode") }, onClick = {
                                menuOpen = false
                                val c = BijoyToUnicode.convert(tfv.text)
                                setText(TextFieldValue(c, TextRange(c.length)), true)
                            })
                            DropdownMenuItem(text = { Text("Insert Bijoy test sheet") }, onClick = {
                                menuOpen = false
                                insertExact(BIJOY_TEST_WORDS.joinToString("\n") + "\n")
                            })
                            DropdownMenuItem(text = { Text("Import SutonnyMJ font (.ttf)") }, onClick = {
                                menuOpen = false
                                fontLauncher.launch(arrayOf("*/*"))
                            })
                            DropdownMenuItem(text = { Text("About / limitations") }, onClick = {
                                menuOpen = false
                                showAbout = true
                            })
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (showSettings) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ChipGroup("Language", listOf("বাংলা", "English"), if (langBangla) 0 else 1, Modifier.weight(1f)) {
                                if (listening) controller.stop()
                                langBangla = it == 0
                            }
                            ChipGroup("Recognition", listOf("Online", "Offline"), if (offline) 1 else 0, Modifier.weight(1f)) {
                                if (listening) controller.stop()
                                offline = it == 1
                            }
                        }
                        ChipGroup("Output format", listOf("Unicode", "SutonnyMJ (Bijoy ANSI)"), if (sutonny) 1 else 0, Modifier.fillMaxWidth()) {
                            sutonny = it == 1
                        }
                        ChipGroup("Input method", listOf("Voice / keyboard", "Avro phonetic box"), if (avroMode) 1 else 0, Modifier.fillMaxWidth()) {
                            avroMode = it == 1
                        }
                    }
                }
            }

            if (offline) {
                OfflineNotice(
                    status = offlineStatus,
                    langName = langName,
                    onDownload = {
                        if (controller.requestOfflineDownload(langTag())) {
                            say("Download requested. Wait a moment, then toggle Offline again to re-check.")
                        } else {
                            say("Open Google app > Settings > Voice > Offline speech recognition and download $langName.")
                        }
                    },
                    onOpenSettings = {
                        try {
                            context.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
                        } catch (_: Exception) {
                            say("Could not open voice settings on this phone.")
                        }
                    }
                )
            }

            OutlinedTextField(
                value = tfv,
                onValueChange = { nv ->
                    if (nv.text != tfv.text) undo.record(tfv.text, nv.text, false)
                    tfv = nv
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .heightIn(min = 120.dp)
                    .focusRequester(focus),
                textStyle = TextStyle(fontSize = 20.sp, lineHeight = 30.sp),
                placeholder = { Text("Tap the microphone and speak, or type here…") }
            )

            if (partial.isNotEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Text(
                        "🎙 " + partial,
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (ansiPreview != null) {
                Card {
                    Column(Modifier.padding(10.dp)) {
                        Text(
                            if (font == null) "SutonnyMJ preview (no font imported: glyphs look garbled here, " +
                                "but copy / TXT / DOCX output is still correct Bijoy ANSI)"
                            else "SutonnyMJ preview (using your imported font)",
                            style = MaterialTheme.typography.labelSmall
                        )
                        Box(Modifier.heightIn(max = 84.dp).verticalScroll(rememberScrollState())) {
                            Text(ansiPreview, style = TextStyle(fontSize = 18.sp))
                        }
                    }
                }
            }

            if (avroMode) {
                Card {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            "Type English letters (e.g. ami bangla), press Space to convert:",
                            style = MaterialTheme.typography.labelSmall
                        )
                        Text(
                            if (phonetic.isEmpty()) "…" else AvroPhonetic.transliterate(phonetic),
                            style = TextStyle(fontSize = 20.sp),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = phonetic,
                                onValueChange = { v ->
                                    if (v.contains(' ') || v.contains('\n')) {
                                        val word = v.trim()
                                        if (word.isNotEmpty()) {
                                            insertExact(AvroPhonetic.transliterate(word) + (if (v.endsWith("\n")) "\n" else " "))
                                        }
                                        phonetic = ""
                                    } else {
                                        phonetic = v
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                singleLine = false,
                                maxLines = 2,
                                keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, keyboardType = KeyboardType.Ascii),
                                placeholder = { Text("Phonetic input") }
                            )
                            Button(onClick = {
                                if (phonetic.isNotEmpty()) insertExact(AvroPhonetic.transliterate(phonetic))
                                phonetic = ""
                            }) { Text("Insert") }
                        }
                    }
                }
            }

            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip(onClick = { copyText() }, label = { Text("Copy") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { pasteText(false) }, label = { Text("Paste") }, leadingIcon = { Icon(Icons.Filled.ContentPaste, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { selectAll() }, label = { Text("Select all") }, leadingIcon = { Icon(Icons.Filled.SelectAll, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { doUndo() }, enabled = undo.canUndo, label = { Text("Undo") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.Undo, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { doRedo() }, enabled = undo.canRedo, label = { Text("Redo") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.Redo, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { setText(TextFieldValue(""), true) }, label = { Text("Clear") }, leadingIcon = { Icon(Icons.Filled.DeleteSweep, null, Modifier.size(18.dp)) })
            }

            Text(
                if (listening) "● Listening — $langName, " + (if (offline) "Offline" else "Online") + " (tap to stop)"
                else "Tap the microphone to start voice typing ($langName)",
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.labelLarge,
                color = if (listening) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { txtLauncher.launch(fileName("txt")) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp)) {
                    Icon(Icons.Filled.Save, null, Modifier.size(18.dp))
                    Spacer4()
                    Text("TXT", maxLines = 1)
                }
                MicButton(listening = listening, onClick = { toggleMic() })
                Button(onClick = { docxLauncher.launch(fileName("docx")) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp)) {
                    Icon(Icons.Filled.Description, null, Modifier.size(18.dp))
                    Spacer4()
                    Text("DOCX", maxLines = 1)
                }
            }
            Button(
                onClick = {
                    if (sutonny && font == null) showFontDialog = true else pdfLauncher.launch(fileName("pdf"))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.PictureAsPdf, null, Modifier.size(18.dp))
                Spacer4()
                Text("Export PDF (" + (if (sutonny) "SutonnyMJ" else "Unicode") + ")")
            }
        }
    }

    if (showFontDialog) {
        AlertDialog(
            onDismissRequest = { showFontDialog = false },
            title = { Text("SutonnyMJ font needed for PDF") },
            text = {
                Text(
                    "A SutonnyMJ PDF can only look right if the font is embedded. SutonnyMJ is a commercial font " +
                        "and is not bundled with this app. Import your own licensed SutonnyMJ.ttf, or export as " +
                        "DOCX (opens correctly on PCs that have SutonnyMJ) or as a Unicode PDF."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showFontDialog = false
                    fontLauncher.launch(arrayOf("*/*"))
                }) { Text("Import font") }
            },
            dismissButton = { TextButton(onClick = { showFontDialog = false }) { Text("Cancel") } }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("About / limitations") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "• Voice recognition is done by your phone's speech service (normally Google). " +
                            "The app has no speech model of its own, so accuracy and offline support depend on that service " +
                            "and on the offline language pack you downloaded.\n\n" +
                            "• Online mode may send audio to the speech provider. Use Offline for sensitive material, " +
                            "after confirming the offline pack is installed.\n\n" +
                            "• SutonnyMJ output is real Unicode → Bijoy ANSI conversion. Common conjuncts use fused " +
                            "glyphs; rarer conjuncts are written with an explicit hasanta. Always check a sample in " +
                            "Word with SutonnyMJ installed (menu → Insert Bijoy test sheet).\n\n" +
                            "• DOCX uses the font name SutonnyMJ (not embedded). English words are kept in a Latin font.\n\n" +
                            "• Avro: the phonetic box is a built-in Avro-style transliterator. You can also type directly " +
                            "in the editor with any Unicode Bangla keyboard (e.g. the Avro Keyboard app).\n\n" +
                            "• There is no on-screen Bijoy keyboard; use \"Paste Bijoy text as Unicode\" to bring legacy text in."
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } }
        )
    }
}

@Composable
private fun Spacer4() {
    androidx.compose.foundation.layout.Spacer(Modifier.width(4.dp))
}

@Composable
private fun ChipGroup(
    title: String,
    options: List<String>,
    selected: Int,
    modifier: Modifier = Modifier,
    onSelect: (Int) -> Unit
) {
    Column(modifier) {
        Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            options.forEachIndexed { i, label ->
                FilterChip(
                    selected = i == selected,
                    onClick = { onSelect(i) },
                    label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp) }
                )
            }
        }
    }
}

@Composable
private fun OfflineNotice(
    status: OfflineStatus,
    langName: String,
    onDownload: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val bad = status == OfflineStatus.DOWNLOAD_NEEDED || status == OfflineStatus.NOT_SUPPORTED
    val msg = when (status) {
        OfflineStatus.CHECKING -> "Checking offline model for $langName…"
        OfflineStatus.AVAILABLE -> "Offline $langName model is installed on this phone."
        OfflineStatus.DOWNLOAD_NEEDED -> "Offline $langName model is NOT installed. Download it, or switch to Online."
        OfflineStatus.NOT_SUPPORTED -> "This phone's speech service has no offline $langName model. Use Online mode."
        OfflineStatus.UNKNOWN -> "Cannot verify the offline $langName model on this Android version. " +
            "If it is missing, voice typing will stop with an error."
    }
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (bad) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(msg, style = MaterialTheme.typography.bodySmall)
            if (status != OfflineStatus.AVAILABLE && status != OfflineStatus.CHECKING) {
                Row {
                    if (status == OfflineStatus.DOWNLOAD_NEEDED) TextButton(onClick = onDownload) { Text("Download") }
                    TextButton(onClick = onOpenSettings) { Text("Voice settings") }
                }
            }
        }
    }
}

@Composable
private fun MicButton(listening: Boolean, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "mic-pulse")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (listening) 1.1f else 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "mic-scale"
    )
    Button(
        onClick = onClick,
        modifier = Modifier
            .size(84.dp)
            .scale(scale),
        shape = CircleShape,
        contentPadding = PaddingValues(0.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (listening) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
        )
    ) {
        Icon(
            if (listening) Icons.Filled.Stop else Icons.Filled.Mic,
            contentDescription = if (listening) "Stop voice typing" else "Start voice typing",
            modifier = Modifier.size(40.dp)
        )
    }
}
