package com.banglavoicewriter.pro.convert

/**
 * Avro-style phonetic transliteration (Roman -> Unicode Bangla).
 *
 * This is an independent implementation of the well-known Avro Phonetic scheme
 * (e.g. "ami" -> আমি, "bangla" -> বাংলা, "shikkha" -> শিক্ষা). It follows the same
 * conventions as Avro Phonetic: capital letters select the retroflex / aspirated
 * forms (T D N R S O U I), "o" is the inherent vowel (no mark), "O" is the o-kar,
 * "ng" = ং, "Ng" = ঙ, "^" = ঁ, ":" = ঃ, "." = ।, ",," = hasanta, and consecutive
 * consonants form a conjunct automatically. It does not copy Avro's dictionary
 * or its auto-correct data, so a few words may differ from Avro Keyboard.
 */
object AvroPhonetic {
    private const val HASANTA = "\u09CD"

    /** Consonant patterns. */
    private val consonants: Map<String, String> = mapOf(
        "kkh" to "\u0995\u09CD\u09B7",
        "chh" to "\u099B",
        "ch" to "\u099A",
        "kh" to "\u0996",
        "gh" to "\u0998",
        "Ng" to "\u0999",
        "jh" to "\u099D",
        "NG" to "\u099E",
        "Th" to "\u09A0",
        "Dh" to "\u09A2",
        "th" to "\u09A5",
        "dh" to "\u09A7",
        "ph" to "\u09AB",
        "bh" to "\u09AD",
        "sh" to "\u09B6",
        "Sh" to "\u09B7",
        "Rh" to "\u09DD",
        "GG" to "\u099C\u09CD\u099E",
        "k" to "\u0995",
        "g" to "\u0997",
        "c" to "\u099A",
        "j" to "\u099C",
        "T" to "\u099F",
        "D" to "\u09A1",
        "N" to "\u09A3",
        "t" to "\u09A4",
        "d" to "\u09A6",
        "n" to "\u09A8",
        "p" to "\u09AA",
        "f" to "\u09AB",
        "b" to "\u09AC",
        "v" to "\u09AD",
        "m" to "\u09AE",
        "z" to "\u09AF",
        "r" to "\u09B0",
        "l" to "\u09B2",
        "S" to "\u09B6",
        "s" to "\u09B8",
        "h" to "\u09B9",
        "R" to "\u09DC",
        "y" to "\u09DF",
        "Y" to "\u09DF",
        "q" to "\u0995",
        "x" to "\u0995\u09CD\u09B8"
    )
    /** Marks and punctuation patterns. */
    private val specials: Map<String, String> = mapOf(
        "ng" to "\u0982",
        ",," to "\u09CD",
        "t``" to "\u09CE",
        "^" to "\u0981",
        ":" to "\u0983",
        "." to "\u0964",
        "\$" to "\u09F3"
    )
    /** Vowel patterns: (independent form, kar form). */
    private val vowels: Map<String, Pair<String, String>> = mapOf(
        "rri" to Pair("\u098B", "\u09C3"),
        "oi" to Pair("\u0990", "\u09C8"),
        "ou" to Pair("\u0994", "\u09CC"),
        "oU" to Pair("\u0994", "\u09CC"),
        "ii" to Pair("\u0988", "\u09C0"),
        "uu" to Pair("\u098A", "\u09C2"),
        "a" to Pair("\u0986", "\u09BE"),
        "i" to Pair("\u0987", "\u09BF"),
        "I" to Pair("\u0988", "\u09C0"),
        "u" to Pair("\u0989", "\u09C1"),
        "U" to Pair("\u098A", "\u09C2"),
        "e" to Pair("\u098F", "\u09C7"),
        "O" to Pair("\u0993", "\u09CB"),
        "o" to Pair("\u0985", "")
    )
    /** ASCII digits to Bangla digits. */
    private val digits: Map<String, String> = mapOf(
        "0" to "\u09E6",
        "1" to "\u09E7",
        "2" to "\u09E8",
        "3" to "\u09E9",
        "4" to "\u09EA",
        "5" to "\u09EB",
        "6" to "\u09EC",
        "7" to "\u09ED",
        "8" to "\u09EE",
        "9" to "\u09EF"
    )
    private const val START = 0
    private const val VOWEL = 1
    private const val CONS = 2
    private const val MARK = 3
    private const val CLOSED = 4

    fun transliterate(text: String): String {
        val out = StringBuilder()
        val n = text.length
        var i = 0
        var state = START
        while (i < n) {
            val ch = text[i]
            if (ch == '`') {
                if (state == CONS) state = CLOSED
                i++
                continue
            }
            val digit = digits[ch.toString()]
            if (digit != null) {
                out.append(digit)
                state = START
                i++
                continue
            }
            // kind: 's' special, 'v' vowel, 'c' consonant, 0 = none
            var kind = ' '
            var key = ""
            var len = 0
            // Multi-character specials first (",,", "t``").
            for (l in 3 downTo 2) {
                if (i + l <= n) {
                    val k = text.substring(i, i + l)
                    if (specials.containsKey(k) && k != "ng") {
                        kind = 's'; key = k; len = l
                        break
                    }
                }
            }
            if (kind == ' ') {
                for (l in 3 downTo 1) {
                    if (i + l > n) continue
                    val k = text.substring(i, i + l)
                    if (l > 1 && vowels.containsKey(k)) { kind = 'v'; key = k; len = l; break }
                    if (specials.containsKey(k) && (l > 1 || k == "^" || k == ":" || k == "." || k == "\$")) {
                        kind = 's'; key = k; len = l; break
                    }
                    if (consonants.containsKey(k)) { kind = 'c'; key = k; len = l; break }
                    if (l == 1 && vowels.containsKey(k)) { kind = 'v'; key = k; len = l; break }
                }
            }
            if (kind == ' ') {
                out.append(ch)
                state = START
                i++
                continue
            }
            i += len
            when (kind) {
                's' -> {
                    if (key == ",,") {
                        out.append(HASANTA)
                        state = CONS
                    } else {
                        out.append(specials[key])
                        state = if (key == "ng" || key == "^" || key == ":" || key == "t``") MARK else START
                    }
                }
                'v' -> {
                    val pair = vowels[key]!!
                    out.append(if (state == CONS) pair.second else pair.first)
                    state = VOWEL
                }
                else -> {
                    val g = consonants[key]!!
                    if (state == CONS) {
                        if (key == "y") out.append(HASANTA).append("\u09AF") else out.append(HASANTA).append(g)
                    } else {
                        out.append(g)
                    }
                    state = CONS
                }
            }
        }
        return out.toString()
    }
}
