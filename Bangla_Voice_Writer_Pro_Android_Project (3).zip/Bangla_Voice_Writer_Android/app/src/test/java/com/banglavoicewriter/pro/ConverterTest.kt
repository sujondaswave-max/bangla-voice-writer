package com.banglavoicewriter.pro

import com.banglavoicewriter.pro.convert.AvroPhonetic
import com.banglavoicewriter.pro.convert.BijoyConverter
import com.banglavoicewriter.pro.convert.BijoyToUnicode
import com.banglavoicewriter.pro.convert.Script
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Expected values were produced by an independent prototype of the same algorithm
 * and the documented Bijoy glyph layout. They verify the implementation is
 * self-consistent; they do NOT prove the glyphs look right in SutonnyMJ
 * (that needs a visual check in Word with the font installed).
 */
class ConverterTest {

    @Test fun toBijoy_0() = assertEquals("evsjv", BijoyConverter.toBijoy("\u09AC\u09BE\u0982\u09B2\u09BE")) // বাংলা
    @Test fun toBijoy_1() = assertEquals("Avwg", BijoyConverter.toBijoy("\u0986\u09AE\u09BF")) // আমি
    @Test fun toBijoy_2() = assertEquals("wk\u00B6v", BijoyConverter.toBijoy("\u09B6\u09BF\u0995\u09CD\u09B7\u09BE")) // শিক্ষা
    @Test fun toBijoy_3() = assertEquals("my\u203A`i", BijoyConverter.toBijoy("\u09B8\u09C1\u09A8\u09CD\u09A6\u09B0")) // সুন্দর
    @Test fun toBijoy_4() = assertEquals("ag\u00A9", BijoyConverter.toBijoy("\u09A7\u09B0\u09CD\u09AE")) // ধর্ম
    @Test fun toBijoy_5() = assertEquals("c\u00D6_g", BijoyConverter.toBijoy("\u09AA\u09CD\u09B0\u09A5\u09AE")) // প্রথম
    @Test fun toBijoy_6() = assertEquals("D\u00CBi", BijoyConverter.toBijoy("\u0989\u09A4\u09CD\u09A4\u09B0")) // উত্তর
    @Test fun toBijoy_7() = assertEquals("kvw\u0161\u00CD", BijoyConverter.toBijoy("\u09B6\u09BE\u09A8\u09CD\u09A4\u09BF")) // শান্তি
    @Test fun toBijoy_8() = assertEquals("we\u00C1vb", BijoyConverter.toBijoy("\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09A8")) // বিজ্ঞান
    @Test fun toBijoy_9() = assertEquals("m\u00A4\u00FAK\u00A9", BijoyConverter.toBijoy("\u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995")) // সম্পর্ক
    @Test fun toBijoy_10() = assertEquals("e\u00A8envi", BijoyConverter.toBijoy("\u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0")) // ব্যবহার
    @Test fun toBijoy_11() = assertEquals("\u2021Kv_vq", BijoyConverter.toBijoy("\u0995\u09CB\u09A5\u09BE\u09DF")) // কোথায়
    @Test fun toBijoy_12() = assertEquals("\u02DC`wbK", BijoyConverter.toBijoy("\u09A6\u09C8\u09A8\u09BF\u0995")) // দৈনিক
    @Test fun toBijoy_13() = assertEquals("B\u201DQv", BijoyConverter.toBijoy("\u0987\u099A\u09CD\u099B\u09BE")) // ইচ্ছা
    @Test fun toBijoy_14() = assertEquals("hy\u00B3", BijoyConverter.toBijoy("\u09AF\u09C1\u0995\u09CD\u09A4")) // যুক্ত
    @Test fun toBijoy_15() = assertEquals("m\u201Ew\u00F3", BijoyConverter.toBijoy("\u09B8\u09C3\u09B7\u09CD\u099F\u09BF")) // সৃষ্টি
    @Test fun toBijoy_16() = assertEquals("m~h\u00A9", BijoyConverter.toBijoy("\u09B8\u09C2\u09B0\u09CD\u09AF")) // সূর্য
    @Test fun toBijoy_17() = assertEquals("evsjv\u2021`k", BijoyConverter.toBijoy("\u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6")) // বাংলাদেশ
    @Test fun toBijoy_18() = assertEquals("Kg\u00A9x", BijoyConverter.toBijoy("\u0995\u09B0\u09CD\u09AE\u09C0")) // কর্মী
    @Test fun toBijoy_19() = assertEquals("i\u00A8ve", BijoyConverter.toBijoy("\u09B0\u200D\u09CD\u09AF\u09BE\u09AC")) // র‍্যাব
    @Test fun toBijoy_20() = assertEquals("\u2021K\u0160kj", BijoyConverter.toBijoy("\u0995\u09CC\u09B6\u09B2")) // কৌশল
    @Test fun toBijoy_21() = assertEquals("eZ\u00A9gv\u2021b", BijoyConverter.toBijoy("\u09AC\u09B0\u09CD\u09A4\u09AE\u09BE\u09A8\u09C7")) // বর্তমানে
    @Test fun toBijoy_22() = assertEquals("m\u2021e\u00A9v\u201DP", BijoyConverter.toBijoy("\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A")) // সর্বোচ্চ
    @Test fun toBijoy_23() = assertEquals("g~j\u00A8", BijoyConverter.toBijoy("\u09AE\u09C2\u09B2\u09CD\u09AF")) // মূল্য
    @Test fun toBijoy_24() = assertEquals("KK&K N&i 123 |", BijoyConverter.toBijoy("\u0995\u0995\u09CD\u0995 \u0998\u09CD\u09B0 \u09E7\u09E8\u09E9 \u0964")) // কক্ক ঘ্র ১২৩ ।
    @Test fun toBijoy_25() = assertEquals("XvKv kn\u2021i A\u2021bK gvbyl _v\u2021Kb|", BijoyConverter.toBijoy("\u09A2\u09BE\u0995\u09BE \u09B6\u09B9\u09B0\u09C7 \u0985\u09A8\u09C7\u0995 \u09AE\u09BE\u09A8\u09C1\u09B7 \u09A5\u09BE\u0995\u09C7\u09A8\u0964")) // ঢাকা শহরে অনেক মানুষ থাকেন।
    @Test fun toBijoy_26() = assertEquals("\u2021Kv_vq", BijoyConverter.toBijoy("\u0995\u09CB\u09A5\u09BE\u09AF\u09BC")) // কোথায়

    @Test fun roundTrip_0() = assertEquals(BijoyConverter.normalize("\u09AC\u09BE\u0982\u09B2\u09BE"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09AC\u09BE\u0982\u09B2\u09BE"))) // বাংলা
    @Test fun roundTrip_1() = assertEquals(BijoyConverter.normalize("\u0986\u09AE\u09BF"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u0986\u09AE\u09BF"))) // আমি
    @Test fun roundTrip_2() = assertEquals(BijoyConverter.normalize("\u09B6\u09BF\u0995\u09CD\u09B7\u09BE"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09B6\u09BF\u0995\u09CD\u09B7\u09BE"))) // শিক্ষা
    @Test fun roundTrip_3() = assertEquals(BijoyConverter.normalize("\u09B8\u09C1\u09A8\u09CD\u09A6\u09B0"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09B8\u09C1\u09A8\u09CD\u09A6\u09B0"))) // সুন্দর
    @Test fun roundTrip_4() = assertEquals(BijoyConverter.normalize("\u09A7\u09B0\u09CD\u09AE"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09A7\u09B0\u09CD\u09AE"))) // ধর্ম
    @Test fun roundTrip_5() = assertEquals(BijoyConverter.normalize("\u09AA\u09CD\u09B0\u09A5\u09AE"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09AA\u09CD\u09B0\u09A5\u09AE"))) // প্রথম
    @Test fun roundTrip_6() = assertEquals(BijoyConverter.normalize("\u0989\u09A4\u09CD\u09A4\u09B0"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u0989\u09A4\u09CD\u09A4\u09B0"))) // উত্তর
    @Test fun roundTrip_7() = assertEquals(BijoyConverter.normalize("\u09B6\u09BE\u09A8\u09CD\u09A4\u09BF"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09B6\u09BE\u09A8\u09CD\u09A4\u09BF"))) // শান্তি
    @Test fun roundTrip_8() = assertEquals(BijoyConverter.normalize("\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09A8"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09A8"))) // বিজ্ঞান
    @Test fun roundTrip_9() = assertEquals(BijoyConverter.normalize("\u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995"))) // সম্পর্ক
    @Test fun roundTrip_10() = assertEquals(BijoyConverter.normalize("\u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0"))) // ব্যবহার
    @Test fun roundTrip_11() = assertEquals(BijoyConverter.normalize("\u0995\u09CB\u09A5\u09BE\u09DF"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u0995\u09CB\u09A5\u09BE\u09DF"))) // কোথায়
    @Test fun roundTrip_12() = assertEquals(BijoyConverter.normalize("\u09A6\u09C8\u09A8\u09BF\u0995"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09A6\u09C8\u09A8\u09BF\u0995"))) // দৈনিক
    @Test fun roundTrip_13() = assertEquals(BijoyConverter.normalize("\u0987\u099A\u09CD\u099B\u09BE"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u0987\u099A\u09CD\u099B\u09BE"))) // ইচ্ছা
    @Test fun roundTrip_14() = assertEquals(BijoyConverter.normalize("\u09AF\u09C1\u0995\u09CD\u09A4"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09AF\u09C1\u0995\u09CD\u09A4"))) // যুক্ত
    @Test fun roundTrip_15() = assertEquals(BijoyConverter.normalize("\u09B8\u09C3\u09B7\u09CD\u099F\u09BF"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09B8\u09C3\u09B7\u09CD\u099F\u09BF"))) // সৃষ্টি
    @Test fun roundTrip_16() = assertEquals(BijoyConverter.normalize("\u09B8\u09C2\u09B0\u09CD\u09AF"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09B8\u09C2\u09B0\u09CD\u09AF"))) // সূর্য
    @Test fun roundTrip_17() = assertEquals(BijoyConverter.normalize("\u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6"))) // বাংলাদেশ
    @Test fun roundTrip_18() = assertEquals(BijoyConverter.normalize("\u0995\u09B0\u09CD\u09AE\u09C0"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u0995\u09B0\u09CD\u09AE\u09C0"))) // কর্মী
    @Test fun roundTrip_19() = assertEquals(BijoyConverter.normalize("\u09B0\u200D\u09CD\u09AF\u09BE\u09AC"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09B0\u200D\u09CD\u09AF\u09BE\u09AC"))) // র‍্যাব
    @Test fun roundTrip_20() = assertEquals(BijoyConverter.normalize("\u0995\u09CC\u09B6\u09B2"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u0995\u09CC\u09B6\u09B2"))) // কৌশল
    @Test fun roundTrip_21() = assertEquals(BijoyConverter.normalize("\u09AC\u09B0\u09CD\u09A4\u09AE\u09BE\u09A8\u09C7"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09AC\u09B0\u09CD\u09A4\u09AE\u09BE\u09A8\u09C7"))) // বর্তমানে
    @Test fun roundTrip_22() = assertEquals(BijoyConverter.normalize("\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A"))) // সর্বোচ্চ
    @Test fun roundTrip_23() = assertEquals(BijoyConverter.normalize("\u09AE\u09C2\u09B2\u09CD\u09AF"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09AE\u09C2\u09B2\u09CD\u09AF"))) // মূল্য
    @Test fun roundTrip_24() = assertEquals(BijoyConverter.normalize("\u0995\u0995\u09CD\u0995 \u0998\u09CD\u09B0 \u09E7\u09E8\u09E9 \u0964"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u0995\u0995\u09CD\u0995 \u0998\u09CD\u09B0 \u09E7\u09E8\u09E9 \u0964"))) // কক্ক ঘ্র ১২৩ ।
    @Test fun roundTrip_25() = assertEquals(BijoyConverter.normalize("\u09A2\u09BE\u0995\u09BE \u09B6\u09B9\u09B0\u09C7 \u0985\u09A8\u09C7\u0995 \u09AE\u09BE\u09A8\u09C1\u09B7 \u09A5\u09BE\u0995\u09C7\u09A8\u0964"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u09A2\u09BE\u0995\u09BE \u09B6\u09B9\u09B0\u09C7 \u0985\u09A8\u09C7\u0995 \u09AE\u09BE\u09A8\u09C1\u09B7 \u09A5\u09BE\u0995\u09C7\u09A8\u0964"))) // ঢাকা শহরে অনেক মানুষ থাকেন।
    @Test fun roundTrip_26() = assertEquals(BijoyConverter.normalize("\u0995\u09CB\u09A5\u09BE\u09AF\u09BC"), BijoyToUnicode.convert(BijoyConverter.toBijoy("\u0995\u09CB\u09A5\u09BE\u09AF\u09BC"))) // কোথায়

    @Test fun segments_separateLatinFromBangla() {
        val segs = BijoyConverter.convertSegments("\u0986\u09AE\u09BF Hello 123 \u0986\u09AE\u09BF")
        assertEquals(listOf(Script.BANGLA, Script.LATIN, Script.BANGLA), segs.map { it.script })
        assertEquals("Hello 123 ", segs[1].text)
        assertEquals("Avwg Hello 123 Avwg", segs.joinToString("") { it.text })
    }

    @Test fun smartQuotesOnlyConvertedInsideBangla() {
        assertEquals("\u00D2Avwg\u00D3", BijoyConverter.toBijoy("\u201C\u0986\u09AE\u09BF\u201D"))
        assertEquals("\u201CHi\u201D", BijoyConverter.toBijoy("\u201CHi\u201D"))
    }

    @Test fun decomposedNuktaIsNormalised() {
        assertEquals(BijoyConverter.toBijoy("\u09AF\u09DF"), BijoyConverter.toBijoy("\u09AF\u09AF\u09BC"))
    }

    @Test fun unknownConjunctFallsBackToExplicitHasanta() {
        // k + hasanta + k is not in the ligature table -> readable explicit hasanta, never dropped
        assertTrue(BijoyConverter.toBijoy("\u0995\u09CD\u09AC").contains("&"))
    }

    @Test fun everyBijoyGlyphIsEncodableInWindows1252() {
        val enc = charset("windows-1252").newEncoder()
        for (w in listOf(
"\u09AC\u09BE\u0982\u09B2\u09BE",
            "\u0986\u09AE\u09BF",
            "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE",
            "\u09B8\u09C1\u09A8\u09CD\u09A6\u09B0",
            "\u09A7\u09B0\u09CD\u09AE",
            "\u09AA\u09CD\u09B0\u09A5\u09AE",
            "\u0989\u09A4\u09CD\u09A4\u09B0",
            "\u09B6\u09BE\u09A8\u09CD\u09A4\u09BF",
            "\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09A8",
            "\u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995",
            "\u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0",
            "\u0995\u09CB\u09A5\u09BE\u09DF",
            "\u09A6\u09C8\u09A8\u09BF\u0995",
            "\u0987\u099A\u09CD\u099B\u09BE",
            "\u09AF\u09C1\u0995\u09CD\u09A4",
            "\u09B8\u09C3\u09B7\u09CD\u099F\u09BF",
            "\u09B8\u09C2\u09B0\u09CD\u09AF",
            "\u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6",
            "\u0995\u09B0\u09CD\u09AE\u09C0",
            "\u09B0\u200D\u09CD\u09AF\u09BE\u09AC",
            "\u0995\u09CC\u09B6\u09B2",
            "\u09AC\u09B0\u09CD\u09A4\u09AE\u09BE\u09A8\u09C7",
            "\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A",
            "\u09AE\u09C2\u09B2\u09CD\u09AF",
            "\u0995\u0995\u09CD\u0995 \u0998\u09CD\u09B0 \u09E7\u09E8\u09E9 \u0964",
            "\u09A2\u09BE\u0995\u09BE \u09B6\u09B9\u09B0\u09C7 \u0985\u09A8\u09C7\u0995 \u09AE\u09BE\u09A8\u09C1\u09B7 \u09A5\u09BE\u0995\u09C7\u09A8\u0964",
            "\u0995\u09CB\u09A5\u09BE\u09AF\u09BC"

        )) {
            val b = BijoyConverter.toBijoy(w)
            assertTrue("not cp1252: $b", enc.canEncode(b))
        }
    }
}

class AvroPhoneticTest {
    @Test fun avro_0() = assertEquals("\u0986\u09AE\u09BF", AvroPhonetic.transliterate("ami")) // ami -> আমি
    @Test fun avro_1() = assertEquals("\u0986\u09AE\u09BE\u09B0", AvroPhonetic.transliterate("amar")) // amar -> আমার
    @Test fun avro_2() = assertEquals("\u09AC\u09BE\u0982\u09B2\u09BE", AvroPhonetic.transliterate("bangla")) // bangla -> বাংলা
    @Test fun avro_3() = assertEquals("\u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6", AvroPhonetic.transliterate("bangladesh")) // bangladesh -> বাংলাদেশ
    @Test fun avro_4() = assertEquals("\u09A4\u09C1\u09AE\u09BF", AvroPhonetic.transliterate("tumi")) // tumi -> তুমি
    @Test fun avro_5() = assertEquals("\u09B6\u09BF\u0995\u09CD\u09B7\u09BE", AvroPhonetic.transliterate("shikkha")) // shikkha -> শিক্ষা
    @Test fun avro_6() = assertEquals("\u09AA\u09CD\u09B0\u09A5\u09AE", AvroPhonetic.transliterate("prothom")) // prothom -> প্রথম
    @Test fun avro_7() = assertEquals("\u09A7\u09B0\u09CD\u09AE", AvroPhonetic.transliterate("dhormo")) // dhormo -> ধর্ম
    @Test fun avro_8() = assertEquals("\u09B8\u09C1\u09A8\u09CD\u09A6\u09B0", AvroPhonetic.transliterate("sundor")) // sundor -> সুন্দর
    @Test fun avro_9() = assertEquals("\u0995\u09A5\u09BE\u09DF", AvroPhonetic.transliterate("kothay")) // kothay -> কথায়
    @Test fun avro_10() = assertEquals("\u09A2\u09BE\u0995\u09BE", AvroPhonetic.transliterate("Dhaka")) // Dhaka -> ঢাকা
    @Test fun avro_11() = assertEquals("\u0995\u09BF \u0996\u09AC\u09B0", AvroPhonetic.transliterate("ki khobor")) // ki khobor -> কি খবর
    @Test fun avro_12() = assertEquals("\u0986\u09AE\u09CD\u09B0\u09BE", AvroPhonetic.transliterate("amra")) // amra -> আম্রা
    @Test fun avro_13() = assertEquals("\u0995\u09CB\u09A8", AvroPhonetic.transliterate("kOn")) // kOn -> কোন
    @Test fun avro_14() = assertEquals("\u09B9\u09C8", AvroPhonetic.transliterate("hoi")) // hoi -> হৈ
    @Test fun avro_15() = assertEquals("\u09A4\u09CD\u0995 \u09E7\u09E8\u0964", AvroPhonetic.transliterate("tk 12.")) // tk 12. -> ত্ক ১২।
    @Test fun avro_16() = assertEquals("\u09AD\u09BE\u09B2", AvroPhonetic.transliterate("bhalo")) // bhalo -> ভাল
}
