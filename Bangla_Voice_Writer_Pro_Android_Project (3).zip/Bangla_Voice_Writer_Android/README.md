# Bangla Voice Writer Pro (Android, Kotlin + Jetpack Compose)

Voice typing (Bangla / English), Unicode and **SutonnyMJ (Bijoy ANSI)** output,
TXT / DOCX / PDF export. Min Android 8.0 (API 26). Only permission: `RECORD_AUDIO`.

## Build the APK (no Android Studio needed): GitHub Actions
1. Create a new GitHub repository and upload **all files of this folder**
   (keep the `.github/workflows/android-apk.yml` path).
2. Open the repo → **Actions** → *Build Android APK* → **Run workflow**
   (it also runs on every push to `main`).
3. When it finishes (about 5-8 minutes) open the run → **Artifacts**:
   * `Bangla-Voice-Writer-Pro-debug-apk` → `app-debug.apk`
   * `Bangla-Voice-Writer-Pro-release-apk` → `app-release.apk` (signed)
   * `unit-test-report` → HTML test results
4. Download, unzip the artifact, copy the `.apk` to your phone.

Optional (recommended for the release APK): add repository secrets
`KEYSTORE_BASE64` (base64 of your .jks), `KEYSTORE_PASSWORD`, `KEY_ALIAS`,
`KEY_PASSWORD`. Without them a throw-away key is generated on every run, so a
new release APK cannot update an older one (uninstall first, or use debug).

## Build locally (Android Studio)
Open this folder in Android Studio (Ladybug or newer, JDK 17) → let Gradle sync →
*Build ▸ Build APK(s)*. Output: `app/build/outputs/apk/debug/app-debug.apk`.
Command line (Gradle 8.9): `gradle assembleDebug` / `gradle assembleRelease` / `gradle testDebugUnitTest`.

## Install on the phone
Copy the APK to the phone → open it from *Files* → allow "Install unknown apps"
for that app when asked → Install. First start: allow the microphone.

## How it works / limits (please read)
* **Speech engine**: the phone's own speech service (normally Google), used through
  Android `SpeechRecognizer` for live partial text and continuous dictation.
  The app has **no speech model of its own**. There is no public Bangla offline
  model that could be bundled reliably, so *Offline* means "on-device recognition
  of the phone's speech service". On Android 13+ the app checks whether the offline
  Bangla pack is installed and offers to download it; on older Android it cannot
  check and will show an error if the pack is missing. *Online* may send audio to
  the speech provider.
* **Unicode → SutonnyMJ**: own converter (`convert/BijoyConverter.kt`): consonants,
  vowels, kar with pre-base reordering (ি ে ৈ ো ৌ), reph, ya-phala, ra-phala,
  digits, danda, smart quotes, and a table of common conjunct ligatures
  (`convert/BijoyTables.kt`). Conjuncts not in the table are written with an explicit
  hasanta glyph (readable, but not a fused ligature). **The glyph table was written
  from the documented Bijoy layout and checked for internal consistency, but I could
  not render it in a real SutonnyMJ font. Verify it:** menu ▸ *Insert Bijoy test sheet*,
  export DOCX, open on a PC with SutonnyMJ, and report/fix any wrong glyph in
  `BijoyTables.kt` (one line per entry).
* **Reverse**: Bijoy ANSI → Unicode (`BijoyToUnicode`) for pasted legacy text.
  Only give it Bijoy text (English words would be misread).
* **DOCX**: written by a small built-in writer (no libraries). SutonnyMJ DOCX names the
  font but does **not embed** it; it displays correctly on computers that have SutonnyMJ.
  English words stay in a Latin font (otherwise they would show as Bangla glyphs).
* **PDF**: Unicode PDF uses the phone's Bangla system font (shaping by Android).
  SutonnyMJ PDF needs your own licensed `SutonnyMJ.ttf` (menu ▸ *Import SutonnyMJ font*);
  the app refuses to export a SutonnyMJ PDF without it. The font is not bundled.
* **TXT**: Unicode = UTF-8 with BOM; SutonnyMJ = Windows-1252 bytes (legacy ANSI).
* **Avro**: built-in Avro-style phonetic box (`convert/AvroPhonetic.kt`), independent
  implementation (no Avro dictionary / autocorrect). Normal typing in the editor also
  works with any Unicode Bangla keyboard, e.g. the Avro Keyboard app.
* **Bijoy typing**: there is no on-screen Bijoy-layout keyboard; legacy Bijoy text is
  brought in through *Paste Bijoy text as Unicode*.
* The draft text is autosaved when the app goes to background.

## Project layout
```
app/src/main/java/com/banglavoicewriter/pro/
  App.kt, MainActivity.kt, Theme.kt        UI
  speech/SpeechController.kt               recognition, online/offline, offline-pack check
  convert/  BijoyTables, BijoyConverter, BijoyToUnicode, AvroPhonetic
  export/   DocxWriter, PdfWriter, Exporters (TXT), FontStore
  editor/   UndoManager, TextInsert
app/src/test/...                           unit tests (converters, DOCX, TXT)
tools/reference_prototype/                 Python prototypes the tests' expectations came from
```
