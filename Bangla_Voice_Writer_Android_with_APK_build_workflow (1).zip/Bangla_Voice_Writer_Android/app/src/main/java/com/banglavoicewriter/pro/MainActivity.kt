package com.banglavoicewriter.pro

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BanglaVoiceWriterApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BanglaVoiceWriterApp() {
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    var typingMode by remember { mutableStateOf("Voice") }
    var outputMode by remember { mutableStateOf("Unicode") }
    var voiceMode by remember { mutableStateOf("Online / Device Speech Service") }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                text = if (text.isBlank()) spoken else text.trimEnd() + " " + spoken
            }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                    it.write(text)
                }
            }.onSuccess {
                Toast.makeText(context, "ফাইল সংরক্ষণ হয়েছে", Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, "ফাইল সংরক্ষণ করা যায়নি", Toast.LENGTH_LONG).show()
            }
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Text("বাংলা ভয়েস রাইটার প্রো", fontWeight = FontWeight.Bold)
                })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Android Edition · Starter 1.0", style = MaterialTheme.typography.labelLarge)
                Text("Typing Mode", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Voice", "Avro", "Bijoy").forEach { mode ->
                        FilterChip(
                            selected = typingMode == mode,
                            onClick = { typingMode = mode },
                            label = { Text(mode) }
                        )
                    }
                }

                Text("Output Format", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Unicode", "SutonnyMJ").forEach { mode ->
                        FilterChip(
                            selected = outputMode == mode,
                            onClick = { outputMode = mode },
                            label = { Text(mode) }
                        )
                    }
                }

                Text("Voice Service", fontWeight = FontWeight.SemiBold)
                Text(
                    "এই Starter সংস্করণে Android-এর Speech Recognition service ব্যবহার হয়। " +
                    "Online/offline সুবিধা ফোনে ইনস্টল করা speech service ও ভাষা-প্যাকের ওপর নির্ভরশীল।",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedButton(
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় কথা বলুন")
                            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                        }
                        try {
                            speechLauncher.launch(intent)
                        } catch (_: Exception) {
                            Toast.makeText(context, "এই ফোনে Speech Recognition service পাওয়া যায়নি", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("মাইক্রোফোন দিয়ে বাংলা বলুন")
                }

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 260.dp),
                    label = { Text("বাংলা লেখার জায়গা") },
                    placeholder = { Text("এখানে কথা থেকে তৈরি হওয়া লেখা দেখা যাবে...") }
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                    as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Bangla text", text))
                            Toast.makeText(context, "লেখা Copy হয়েছে", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Copy")
                    }
                    Button(
                        onClick = { saveLauncher.launch("bangla_note.txt") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Save TXT")
                    }
                }

                OutlinedButton(
                    onClick = { text = "" },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("লেখা মুছুন") }

                HorizontalDivider()
                Text(
                    "গুরুত্বপূর্ণ: Avro/Bijoy keyboard engine এবং Unicode-to-Bijoy ANSI " +
                    "converter এই Starter build-এ এখনো যুক্ত হয়নি। SutonnyMJ নির্বাচনটি " +
                    "এখন UI placeholder; ভুল encoding-এ ফাইল তৈরি করা হবে না। " +
                    "SutonnyMJ ফন্ট সব Android অ্যাপে সরাসরি কাজ নাও করতে পারে।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
